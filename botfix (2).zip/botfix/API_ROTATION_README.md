# API Rotation Feature

## Overview
This feature allows the bot to automatically rotate between multiple Telegram API credentials when facing rate limit errors. This helps to maintain bot functionality even when one API key reaches its limits.

## How It Works
1. The bot loads all API credentials from the `.env` file
2. When a FloodWait or other limit-related error occurs, the bot automatically switches to the next available API key
3. The operation is retried with the new API credentials
4. If all API keys are exhausted, the bot will wait for the required time before retrying

## Usage

### Adding API Credentials
API credentials are stored in the `.env` file in the following format:

```
# Main API credentials
API_ID = "your_main_api_id"
API_HASH = "your_main_api_hash"

# Additional API credentials for rotation
API_ID_1 = "your_api_id_1"
API_HASH_1 = "your_api_hash_1"

API_ID_2 = "your_api_id_2"
API_HASH_2 = "your_api_hash_2"

# Add more as needed
```

### Using Safe API Calls
To use the API rotation feature in your code, wrap your Pyrogram client calls with the `safe_client_call` function:

```python
# Instead of:
# result = await app.some_method(param1, param2)

# Use:
result = await safe_client_call(app.some_method, param1, param2)
```

## Files
- `api_key_manager.py`: Manages loading and rotating API keys
- `api_rotation.py`: Handles API errors and implements the rotation logic
- `.env`: Stores all API credentials

## Troubleshooting

If you encounter issues with API rotation:

1. Check that all API credentials in the `.env` file are valid
2. Ensure the API_ID and API_HASH pairs match correctly
3. Verify that you're using the `safe_client_call` function for operations that might hit rate limits
4. Check the logs for any errors related to API key rotation

## Adding More API Keys

To add more API keys:

1. Get new API credentials from https://my.telegram.org
2. Add them to the `.env` file following the existing pattern
3. Restart the bot to load the new credentials