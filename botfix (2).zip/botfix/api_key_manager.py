import os
import json
from dotenv import load_dotenv
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class APIKeyManager:
    def __init__(self):
        # Load environment variables
        load_dotenv()
        
        # Initialize API keys list
        self.api_keys = []
        self.current_index = 0
        
        # Load API keys from .env file
        self._load_api_keys()
    
    def _load_api_keys(self):
        """
        Load all API keys from .env file
        Format in .env file should be:
        API_ID_1 = "value"
        API_HASH_1 = "value"
        API_ID_2 = "value"
        API_HASH_2 = "value"
        ...
        """
        try:
            # Get the main API credentials
            main_api_id = os.getenv("API_ID")
            main_api_hash = os.getenv("API_HASH")
            
            if main_api_id and main_api_hash:
                self.api_keys.append({
                    "api_id": main_api_id,
                    "api_hash": main_api_hash
                })
            
            # Get additional API credentials if they exist
            i = 1
            while True:
                api_id = os.getenv(f"API_ID_{i}")
                api_hash = os.getenv(f"API_HASH_{i}")
                
                if not api_id or not api_hash:
                    break
                    
                self.api_keys.append({
                    "api_id": api_id,
                    "api_hash": api_hash
                })
                
                i += 1
                
            logger.info(f"Loaded {len(self.api_keys)} API keys")
        except Exception as e:
            logger.error(f"Error loading API keys: {e}")
    
    def get_current_api_key(self):
        """
        Get the current API key
        """
        if not self.api_keys:
            logger.error("No API keys available")
            return None
            
        return self.api_keys[self.current_index]
    
    def rotate_api_key(self):
        """
        Rotate to the next API key
        """
        if not self.api_keys:
            logger.error("No API keys available to rotate")
            return None
            
        self.current_index = (self.current_index + 1) % len(self.api_keys)
        logger.info(f"Rotated to API key index {self.current_index}")
        return self.get_current_api_key()
    
    def get_api_key_count(self):
        """
        Get the number of available API keys
        """
        return len(self.api_keys)

# Create a singleton instance
api_key_manager = APIKeyManager()