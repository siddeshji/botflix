import asyncio
import logging
from typing import Any, Callable, TypeVar, cast
from pyrogram.errors import FloodWait, RPCError
from api_rotation import handle_api_error, with_api_rotation
from api_key_manager import api_key_manager

logger = logging.getLogger(__name__)

# Type variable for function return type
T = TypeVar('T')

async def safe_client_call(client: Any, method_name: str, *args: Any, **kwargs: Any) -> Any:
    """
    Safely execute a client method with automatic API rotation on FloodWait or other API errors.
    
    Args:
        client: The Pyrogram client instance
        method_name: The name of the client method to call
        *args, **kwargs: Arguments to pass to the method
        
    Returns:
        The result of the method call
    """
    # Get the method from the client
    method = getattr(client, method_name)
    if not callable(method):
        raise ValueError(f"{method_name} is not a callable method of the client")
    
    # Get the number of available API keys for retry limit
    max_retries = api_key_manager.get_api_key_count()
    retries = 0
    last_error = None
    
    while retries < max_retries:
        try:
            # Execute the method
            return await method(*args, **kwargs)
        except FloodWait as e:
            last_error = e
            logger.warning(f"FloodWait error in {method_name}: {e}. Waiting {e.value} seconds.")
            
            # Try to rotate API key
            handled = await handle_api_error(client, e)
            
            if handled:
                # API key was rotated, retry immediately
                retries += 1
                logger.info(f"API key rotated, retry {retries}/{max_retries}")
                continue
            else:
                # API key rotation didn't help, wait as instructed
                logger.info(f"Waiting for {e.value} seconds as instructed by FloodWait")
                await asyncio.sleep(e.value)
                continue
        except RPCError as e:
            last_error = e
            logger.warning(f"RPC error in {method_name}: {e}")
            
            # Try to rotate API key
            handled = await handle_api_error(client, e)
            
            if handled:
                # API key was rotated, retry immediately
                retries += 1
                logger.info(f"API key rotated, retry {retries}/{max_retries}")
                continue
            else:
                # API key rotation didn't help, re-raise the exception
                raise
        except Exception as e:
            # For other exceptions, just re-raise
            logger.error(f"Unexpected error in {method_name}: {e}")
            raise
    
    # If we've exhausted all retries
    if last_error:
        logger.error(f"Failed after {max_retries} API key rotations: {last_error}")
        raise last_error
    else:
        raise Exception(f"Failed after {max_retries} API key rotations")

# Convenience wrappers for common client methods
async def safe_download_media(client, message, *args, **kwargs):
    """
    Safely download media with automatic API rotation on error.
    
    This is a wrapper around client.download_media that handles API rotation.
    
    Args:
        client: The Pyrogram client instance
        message: The message containing media to download
        *args, **kwargs: Arguments to pass to download_media
        
    Returns:
        The result of client.download_media
    """
    return await safe_client_call(client, "download_media", message, *args, **kwargs)

async def safe_send_cached_media(client, *args, **kwargs):
    """
    Safely send cached media with automatic API rotation on error.
    
    This is a wrapper around client.send_cached_media that handles API rotation.
    
    Args:
        client: The Pyrogram client instance
        *args, **kwargs: Arguments to pass to send_cached_media
        
    Returns:
        The result of client.send_cached_media
    """
    return await safe_client_call(client, "send_cached_media", *args, **kwargs)

async def safe_send_photo(client, *args, **kwargs):
    """
    Safely send photo with automatic API rotation on error.
    
    Args:
        client: The Pyrogram client instance
        *args, **kwargs: Arguments to pass to send_photo
        
    Returns:
        The result of client.send_photo
    """
    return await safe_client_call(client, "send_photo", *args, **kwargs)

async def safe_send_video(client, *args, **kwargs):
    """
    Safely send video with automatic API rotation on error.
    
    Args:
        client: The Pyrogram client instance
        *args, **kwargs: Arguments to pass to send_video
        
    Returns:
        The result of client.send_video
    """
    return await safe_client_call(client, "send_video", *args, **kwargs)

async def safe_send_document(client, *args, **kwargs):
    """
    Safely send document with automatic API rotation on error.
    
    Args:
        client: The Pyrogram client instance
        *args, **kwargs: Arguments to pass to send_document
        
    Returns:
        The result of client.send_document
    """
    return await safe_client_call(client, "send_document", *args, **kwargs)

async def safe_send_audio(client, *args, **kwargs):
    """
    Safely send audio with automatic API rotation on error.
    
    Args:
        client: The Pyrogram client instance
        *args, **kwargs: Arguments to pass to send_audio
        
    Returns:
        The result of client.send_audio
    """
    return await safe_client_call(client, "send_audio", *args, **kwargs)

async def safe_send_voice(client, *args, **kwargs):
    """
    Safely send voice with automatic API rotation on error.
    
    Args:
        client: The Pyrogram client instance
        *args, **kwargs: Arguments to pass to send_voice
        
    Returns:
        The result of client.send_voice
    """
    return await safe_client_call(client, "send_voice", *args, **kwargs)

async def safe_send_message(client, *args, **kwargs):
    """
    Safely send message with automatic API rotation on error.
    
    Args:
        client: The Pyrogram client instance
        *args, **kwargs: Arguments to pass to send_message
        
    Returns:
        The result of client.send_message
    """
    return await safe_client_call(client, "send_message", *args, **kwargs)