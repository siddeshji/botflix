import logging
from pyrogram.errors import FloodWait, RPCError
from api_key_manager import api_key_manager

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def handle_api_error(client, error):
    """
    Handle API errors by rotating API keys when appropriate
    
    Args:
        client: The Pyrogram client instance
        error: The error that occurred
        
    Returns:
        bool: True if the error was handled and the client should retry, False otherwise
    """
    if isinstance(error, FloodWait):
        logger.warning(f"FloodWait error: {error}. Rotating API key...")
        
        # Rotate to next API key
        new_api_key = api_key_manager.rotate_api_key()
        
        if new_api_key:
            # Update client with new API credentials
            client.api_id = new_api_key["api_id"]
            client.api_hash = new_api_key["api_hash"]
            
            logger.info(f"Rotated to new API key. Will retry operation.")
            return True
        else:
            logger.error("Failed to rotate API key. No more keys available.")
            return False
    
    # For other API errors that might be related to API limits
    elif isinstance(error, RPCError) and any(limit_text in str(error).lower() for limit_text in ["limit", "flood", "wait", "too many"]):
        logger.warning(f"Possible API limit error: {error}. Rotating API key...")
        
        # Rotate to next API key
        new_api_key = api_key_manager.rotate_api_key()
        
        if new_api_key:
            # Update client with new API credentials
            client.api_id = new_api_key["api_id"]
            client.api_hash = new_api_key["api_hash"]
            
            logger.info(f"Rotated to new API key. Will retry operation.")
            return True
        else:
            logger.error("Failed to rotate API key. No more keys available.")
            return False
    
    # For other errors, don't handle here
    return False

async def with_api_rotation(client, func, *args, **kwargs):
    """
    Execute a function with automatic API rotation on error
    
    Args:
        client: The Pyrogram client instance
        func: The async function to execute
        *args, **kwargs: Arguments to pass to the function
        
    Returns:
        The result of the function call
    """
    max_retries = api_key_manager.get_api_key_count()
    retries = 0
    
    while retries < max_retries:
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            handled = await handle_api_error(client, e)
            
            if handled:
                retries += 1
                continue
            else:
                # Re-raise the exception if it wasn't handled
                raise
    
    # If we've exhausted all retries
    raise Exception(f"Failed after {max_retries} API key rotations")